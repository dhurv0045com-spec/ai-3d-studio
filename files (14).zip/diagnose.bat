@echo off
:: ============================================================
:: diagnose.bat
:: AI 3D Studio — Diagnostic & Restart Tool
:: Run this if the app is broken, frozen, or won't start.
:: ============================================================

title AI 3D Studio — Diagnostics
color 0E

echo.
echo  =====================================================
echo   AI 3D Studio — Diagnostics ^& Restart Tool
echo  =====================================================
echo.
echo  This tool will:
echo    1. Check if the server is running
echo    2. Stop any existing server
echo    3. Reset the app state to idle
echo    4. Start a fresh server
echo    5. Test the connection
echo    6. Open the app in your browser
echo.
echo  Press any key to start diagnostics...
pause > nul

:: ────────────────────────────────────────────────────────────
:: Locate project directory (same folder as this .bat file)
:: ────────────────────────────────────────────────────────────
set "PROJECT=%~dp0"
:: Remove trailing backslash
if "%PROJECT:~-1%"=="\" set "PROJECT=%PROJECT:~0,-1%"

echo.
echo  Project folder: %PROJECT%
echo.

:: ────────────────────────────────────────────────────────────
:: STEP 1 — Check if something is already using port 5000
:: ────────────────────────────────────────────────────────────
echo  [Step 1] Checking if server is already running on port 5000...
echo  ---------------------------------------------------------------

netstat -ano | findstr ":5000" > nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo  FOUND — Something is using port 5000.
    for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":5000 "') do (
        echo  Process ID using port 5000: %%p
    )
) else (
    echo  OK — Port 5000 is free. Server was not running.
    goto :reset_state
)

:: ────────────────────────────────────────────────────────────
:: STEP 2 — Kill any existing server process on port 5000
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 2] Stopping existing server...
echo  --------------------------------------

:: Kill all python processes that match server.py
taskkill /F /IM python.exe /FI "WINDOWTITLE eq server*" > nul 2>&1

:: More aggressively kill whatever is on port 5000
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":5000 "') do (
    if NOT "%%p"=="0" (
        echo  Killing PID %%p...
        taskkill /F /PID %%p > nul 2>&1
    )
)

:: Wait a moment for the port to be released
timeout /t 2 /nobreak > nul

:: Confirm port is now free
netstat -ano | findstr ":5000" > nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo  WARNING: Port 5000 may still be in use. Continuing anyway...
) else (
    echo  OK — Server stopped. Port 5000 is now free.
)

:: ────────────────────────────────────────────────────────────
:: STEP 3 — Reset state.json to idle
:: ────────────────────────────────────────────────────────────
:reset_state
echo.
echo  [Step 3] Resetting app state to idle...
echo  -----------------------------------------

set "STATE_FILE=%PROJECT%\state.json"

:: Write the idle state JSON directly
(
echo {
echo   "status":   "idle",
echo   "prompt":   "",
echo   "step":     "ready",
echo   "progress": 0,
echo   "service":  "",
echo   "error":    "",
echo   "log":      []
echo }
) > "%STATE_FILE%"

if %ERRORLEVEL% EQU 0 (
    echo  OK — state.json reset to idle.
) else (
    echo  WARNING: Could not write state.json. Check folder permissions.
    echo  Continuing anyway...
)

:: ────────────────────────────────────────────────────────────
:: STEP 4 — Start a fresh server
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 4] Starting fresh server...
echo  -----------------------------------

python --version > nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  ERROR: Python not found. Cannot start server.
    echo  Please install Python 3.13 from https://www.python.org/downloads/
    pause
    exit /b 1
)

if not exist "%PROJECT%\server.py" (
    echo  ERROR: server.py not found in %PROJECT%
    echo  Make sure all project files are in the same folder.
    pause
    exit /b 1
)

:: Start server in a new minimized window so we can see its output
:: The window title helps taskkill identify it later if needed
start "AI3DStudio-Server" /MIN python "%PROJECT%\server.py"

echo  OK — Server process started.

:: ────────────────────────────────────────────────────────────
:: STEP 5 — Wait 3 seconds, then test /ping endpoint
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 5] Waiting 3 seconds for server to initialize...
echo  --------------------------------------------------------
timeout /t 3 /nobreak > nul

echo  Testing connection to http://localhost:5000/ping ...

:: Try curl first (built into Windows 10+)
curl -s --max-time 5 http://localhost:5000/ping > nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo  OK — Server responded to /ping via curl.
    goto :open_browser
)

:: Fall back to Python requests if curl isn't available or fails
echo  (curl not available, trying Python...)
python -c "import requests; r=requests.get('http://localhost:5000/ping', timeout=5); print('Server responded:', r.status_code)" 2>&1
if %ERRORLEVEL% EQU 0 (
    echo  OK — Server is responding.
    goto :open_browser
)

:: If neither worked, warn the user but continue
echo.
echo  WARNING: Could not verify /ping response.
echo  The server may still be starting up. Opening browser anyway...
echo  If the browser shows an error, wait 10 seconds and refresh.

:: ────────────────────────────────────────────────────────────
:: STEP 6 — Open browser to localhost:5000
:: ────────────────────────────────────────────────────────────
:open_browser
echo.
echo  [Step 6] Opening browser...
echo  ----------------------------
start "" http://localhost:5000

:: ────────────────────────────────────────────────────────────
:: RESULT
:: ────────────────────────────────────────────────────────────
echo.
echo  =====================================================
echo   Server is running. Browser opened.
echo  =====================================================
echo.
echo  If the page doesn't load:
echo    - Wait 10 seconds and press F5 to refresh
echo    - Check logs\server.log for error messages
echo    - Run this diagnose.bat again
echo.

pause
