# tray_launcher.pyw
# AI 3D Studio — Silent System Tray Launcher
# Run this file to start the app. No terminal window will appear.
# Double-click it from File Explorer to launch everything.

import sys
import os
import time
import subprocess
import threading
import webbrowser
from datetime import datetime

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────
PROJECT_DIR   = os.path.dirname(os.path.abspath(__file__))
SERVER_SCRIPT = os.path.join(PROJECT_DIR, "server.py")
LOG_FILE      = os.path.join(PROJECT_DIR, "logs", "server.log")
APP_URL       = "http://localhost:5000"
BROWSER_DELAY = 2.5   # seconds to wait before opening browser
MAX_RESTARTS  = 1     # auto-restart server this many times on crash

# ─────────────────────────────────────────────
# CHECK pystray / pillow ARE INSTALLED
# ─────────────────────────────────────────────
try:
    import pystray
    from PIL import Image, ImageDraw
except ImportError as _import_err:
    # If pystray or Pillow isn't installed, show a plain error dialog
    # using only tkinter (built into Python) and exit.
    import tkinter as tk
    from tkinter import messagebox
    _root = tk.Tk()
    _root.withdraw()
    messagebox.showerror(
        "AI 3D Studio — Missing Package",
        f"A required package is not installed:\n\n{_import_err}\n\n"
        "Please run setup.bat first, then try again."
    )
    _root.destroy()
    sys.exit(1)

# ─────────────────────────────────────────────
# LOGGING HELPER
# ─────────────────────────────────────────────
def log(level: str, message: str):
    """Write a timestamped log entry to logs/server.log and stdout."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    entry = f"[{timestamp}] {level:<5} TRAY: {message}\n"
    # Ensure the logs directory exists
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception:
        pass  # Never crash the launcher because of a logging failure


# ─────────────────────────────────────────────
# DRAW TRAY ICON WITH PILLOW
# Creates a 64×64 image: dark background + cyan glowing hexagon
# ─────────────────────────────────────────────
def create_tray_icon() -> Image.Image:
    """Draw a glowing cyan hexagon on a dark background."""
    import math

    SIZE   = 64
    img    = Image.new("RGBA", (SIZE, SIZE), (15, 15, 25, 255))   # dark navy
    draw   = ImageDraw.Draw(img)

    cx, cy = SIZE // 2, SIZE // 2
    radius = 26

    def hex_points(cx, cy, r):
        """Return 6 corner points of a regular hexagon."""
        pts = []
        for i in range(6):
            angle = math.radians(60 * i - 30)   # flat-top orientation
            pts.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
        return pts

    # Draw glow layers (progressively smaller, more opaque)
    glow_colors = [
        (0, 255, 240, 30),   # outermost glow
        (0, 255, 240, 55),
        (0, 255, 240, 90),
    ]
    for i, color in enumerate(glow_colors):
        r = radius + (3 - i) * 4
        pts = hex_points(cx, cy, r)
        draw.polygon(pts, fill=color)

    # Solid hexagon outline
    pts = hex_points(cx, cy, radius)
    draw.polygon(pts, fill=(0, 200, 210, 220), outline=(0, 255, 240, 255))

    # Inner bright hexagon (smaller) to simulate light core
    inner_pts = hex_points(cx, cy, radius - 10)
    draw.polygon(inner_pts, fill=(180, 255, 250, 160))

    return img


# ─────────────────────────────────────────────
# SERVER PROCESS MANAGER
# ─────────────────────────────────────────────
class ServerManager:
    """
    Manages the lifecycle of server.py:
      - start / stop / restart
      - redirect stdout+stderr to logs/server.log
      - auto-restart once on crash
    """

    def __init__(self):
        self.process     = None          # subprocess.Popen handle
        self.restart_count = 0           # how many times we've auto-restarted
        self.log_file_handle = None      # open file handle for the log
        self._monitor_thread = None
        self._stop_monitor   = False

    # ── open log file ──────────────────────────────────────────────
    def _open_log(self):
        """Open (or re-open) the log file in append mode."""
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        try:
            if self.log_file_handle:
                self.log_file_handle.close()
            self.log_file_handle = open(LOG_FILE, "a", encoding="utf-8")
        except Exception as e:
            log("ERROR", f"cannot open log file: {e}")

    # ── start server ───────────────────────────────────────────────
    def start(self):
        """Launch server.py as a hidden subprocess, piping output to log."""
        self._open_log()

        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"   # force UTF-8 output from server

        try:
            self.process = subprocess.Popen(
                [sys.executable, SERVER_SCRIPT],
                stdout=self.log_file_handle,
                stderr=self.log_file_handle,
                cwd=PROJECT_DIR,
                env=env,
                creationflags=0x08000000,   # CREATE_NO_WINDOW — no console
            )
            log("INFO", f"server started (PID {self.process.pid})")
        except FileNotFoundError:
            log("ERROR", f"server.py not found at {SERVER_SCRIPT}")
            _show_error_dialog(
                "server.py not found.\n"
                "Make sure server.py is in the same folder as this launcher."
            )

    # ── stop server ────────────────────────────────────────────────
    def stop(self):
        """Kill the server process if it is running."""
        self._stop_monitor = True
        if self.process and self.process.poll() is None:
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
                log("INFO", "server stopped gracefully")
            except Exception:
                try:
                    self.process.kill()
                    log("WARN", "server force-killed")
                except Exception as e:
                    log("ERROR", f"could not kill server: {e}")
        if self.log_file_handle:
            try:
                self.log_file_handle.close()
            except Exception:
                pass

    # ── restart server ─────────────────────────────────────────────
    def restart(self):
        """Stop then start the server."""
        log("INFO", "restarting server (user request)")
        self.stop()
        self._stop_monitor = False
        time.sleep(0.8)
        self.start()
        self._begin_monitor()

    # ── monitor thread ─────────────────────────────────────────────
    def _begin_monitor(self):
        """Start a background thread that watches for unexpected crashes."""
        self._stop_monitor = False
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop, daemon=True
        )
        self._monitor_thread.start()

    def _monitor_loop(self):
        """Poll the server process; auto-restart once on unexpected exit."""
        while not self._stop_monitor:
            time.sleep(3)
            if self._stop_monitor:
                break
            if self.process is None:
                continue
            return_code = self.process.poll()
            if return_code is not None:
                # Process has exited
                if self._stop_monitor:
                    break   # intentional quit — don't restart
                log("WARN", f"server crashed (exit code {return_code})")
                if self.restart_count < MAX_RESTARTS:
                    self.restart_count += 1
                    log("WARN", "auto-restarting server...")
                    time.sleep(1)
                    self._stop_monitor = False
                    self.start()
                    log("INFO", "server restarted successfully")
                else:
                    log("ERROR", "server crashed again; giving up auto-restart")
                    _show_error_dialog(
                        "The AI 3D Studio server has crashed and could not\n"
                        "restart automatically.\n\n"
                        "Check logs/server.log for details, then use\n"
                        "'Restart Server' from the tray menu to try again."
                    )
                break


# ─────────────────────────────────────────────
# UTILITY: show error dialog from any thread
# ─────────────────────────────────────────────
def _show_error_dialog(message: str):
    """Display a popup error box. Safe to call from background threads."""
    import tkinter as tk
    from tkinter import messagebox
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("AI 3D Studio — Error", message)
        root.destroy()
    except Exception:
        pass   # If tkinter itself fails, at least we logged the error


# ─────────────────────────────────────────────
# TRAY MENU ACTIONS
# ─────────────────────────────────────────────
def action_open_browser(icon, item):
    """Open the app in the default web browser."""
    log("INFO", f"browser opened {APP_URL}")
    webbrowser.open(APP_URL)


def action_restart_server(icon, item):
    """Kill server.py and start it again."""
    server.restart()


def action_view_logs(icon, item):
    """Open server.log in Notepad."""
    log("INFO", "user opened logs in Notepad")
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    # Touch the file so Notepad always opens something
    if not os.path.exists(LOG_FILE):
        open(LOG_FILE, "w").close()
    subprocess.Popen(
        ["notepad.exe", LOG_FILE],
        creationflags=0x08000000
    )


def action_quit(icon, item):
    """Stop the server, remove tray icon, exit."""
    log("INFO", "user quit — shutting down")
    server.stop()
    icon.stop()


# ─────────────────────────────────────────────
# DELAYED BROWSER OPEN (runs in background thread)
# ─────────────────────────────────────────────
def _open_browser_after_delay():
    """Wait for server to start, then open the browser once."""
    time.sleep(BROWSER_DELAY)
    log("INFO", f"browser opened {APP_URL}")
    webbrowser.open(APP_URL)


# ─────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    log("INFO", "tray launcher starting")

    # 1. Start the server process
    server = ServerManager()
    server.start()
    server._begin_monitor()

    # 2. Open browser after a short delay (gives server time to start)
    threading.Thread(target=_open_browser_after_delay, daemon=True).start()

    # 3. Build the tray icon image
    icon_image = create_tray_icon()

    # 4. Define the tray menu
    menu = pystray.Menu(
        pystray.MenuItem(
            "Open Browser",
            action_open_browser,
            default=True      # double-click action
        ),
        pystray.MenuItem("Restart Server", action_restart_server),
        pystray.MenuItem("View Logs",      action_view_logs),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Quit",           action_quit),
    )

    # 5. Create and run the tray icon (blocks until quit)
    tray_icon = pystray.Icon(
        name="AI3DStudio",
        icon=icon_image,
        title="AI 3D Studio",
        menu=menu
    )

    log("INFO", "tray icon created — running")
    tray_icon.run()

    log("INFO", "tray launcher exited")
