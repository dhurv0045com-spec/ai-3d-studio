# folder_init.py
# AI 3D Studio — Directory & File Initializer
# ─────────────────────────────────────────────────────────────
# Creates all required folders and default files for the project.
# Called by setup.bat during first-time setup, and also imported
# or run by server.py on every startup to ensure structure exists.
#
# Usage:
#   python folder_init.py          ← run directly
#   import folder_init             ← import from server.py (auto-runs)
# ─────────────────────────────────────────────────────────────

import os
import json

# ─────────────────────────────────────────────
# BASE PATH
# Always resolve relative to THIS file's location,
# so it works no matter where Python is called from.
# ─────────────────────────────────────────────
BASE = os.path.dirname(os.path.abspath(__file__))


def _make_dir(rel_path: str):
    """Create a directory (and all parents) if it doesn't already exist."""
    full_path = os.path.join(BASE, rel_path)
    if not os.path.isdir(full_path):
        os.makedirs(full_path, exist_ok=True)
        print(f"  Created: {rel_path}/")
    else:
        print(f"  Exists:  {rel_path}/  (skipped)")


def _make_file(rel_path: str, content: str):
    """
    Create a file with given content ONLY if it doesn't already exist.
    This preserves any existing user data.
    """
    full_path = os.path.join(BASE, rel_path)
    if not os.path.exists(full_path):
        # Ensure parent directory exists
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"  Created: {rel_path}")
    else:
        print(f"  Exists:  {rel_path}  (skipped)")


def _make_empty_file(rel_path: str):
    """Create an empty file (e.g. a log file) if it doesn't exist."""
    full_path = os.path.join(BASE, rel_path)
    if not os.path.exists(full_path):
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        open(full_path, "w", encoding="utf-8").close()
        print(f"  Created: {rel_path}")
    else:
        print(f"  Exists:  {rel_path}  (skipped)")


# ─────────────────────────────────────────────
# MAIN INITIALIZER
# ─────────────────────────────────────────────
def initialize():
    """
    Creates the full directory tree and default files.
    Safe to call multiple times — will never overwrite existing data.
    """
    print()
    print("─" * 50)
    print("  AI 3D Studio — Folder Initializer")
    print("─" * 50)
    print(f"  Project root: {BASE}")
    print()

    # ── 1. DIRECTORIES ─────────────────────────────────────────
    print("  [Directories]")

    _make_dir("models")
    _make_dir("models/cache")
    _make_dir("models/presets")
    _make_dir("logs")
    _make_dir("storage")
    _make_dir("storage/users")
    _make_dir("storage/users/user")
    _make_dir("storage/users/user/default")
    _make_dir("storage/users/user/vehicles")
    _make_dir("storage/users/user/creatures")
    _make_dir("storage/users/user/buildings")
    _make_dir("storage/users/user/misc")

    print()

    # ── 2. LOG FILES (empty) ───────────────────────────────────
    print("  [Log Files]")

    _make_empty_file("logs/server.log")
    _make_empty_file("logs/generation.log")
    _make_empty_file("logs/error.log")

    print()

    # ── 3. JSON DATA FILES ─────────────────────────────────────
    print("  [Data Files]")

    # history.json — list of past generation jobs
    _make_file(
        "history.json",
        "[]"
    )

    # folders.json — list of user folder names
    _make_file(
        "folders.json",
        json.dumps(
            ["default", "vehicles", "creatures", "buildings", "misc"],
            indent=2
        )
    )

    # state.json — current server/generation state (starts as idle)
    idle_state = {
        "status":   "idle",
        "prompt":   "",
        "step":     "ready",
        "progress": 0,
        "service":  "",
        "error":    "",
        "log":      []
    }
    _make_file(
        "state.json",
        json.dumps(idle_state, indent=2)
    )

    # storage/users/user/index.json — index of user's saved models
    _make_file(
        "storage/users/user/index.json",
        "[]"
    )

    print()
    print("─" * 50)
    print("  Initialization complete.")
    print("─" * 50)
    print()


# ─────────────────────────────────────────────
# ENTRY POINT
# Run initialize() whether called directly or imported.
# ─────────────────────────────────────────────
initialize()
