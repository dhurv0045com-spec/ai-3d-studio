@echo off
:: ============================================================
:: setup.bat
:: AI 3D Studio — First-Time Setup
:: Run this ONCE before using the app for the first time.
:: ============================================================

title AI 3D Studio — First-Time Setup
color 0A

echo.
echo  =====================================================
echo   AI 3D Studio — First-Time Setup
echo  =====================================================
echo.
echo  This will set up everything the app needs to run:
echo    - Create required folders
echo    - Create default settings files
echo    - Install Python packages
echo    - Check for Blender
echo.
echo  You only need to run this once.
echo.
echo  Press any key to begin...
pause > nul

:: ────────────────────────────────────────────────────────────
:: Determine project directory (where this .bat file lives)
:: ────────────────────────────────────────────────────────────
set "PROJECT=%~dp0"
if "%PROJECT:~-1%"=="\" set "PROJECT=%PROJECT:~0,-1%"

echo.
echo  Setting up project at: %PROJECT%
echo.

:: ────────────────────────────────────────────────────────────
:: STEP 1 — Create all required directories
:: ────────────────────────────────────────────────────────────
echo  [Step 1] Creating folder structure...
echo  ---------------------------------------

call :make_dir "%PROJECT%\models"
call :make_dir "%PROJECT%\models\cache"
call :make_dir "%PROJECT%\models\presets"
call :make_dir "%PROJECT%\logs"
call :make_dir "%PROJECT%\storage"
call :make_dir "%PROJECT%\storage\users"
call :make_dir "%PROJECT%\storage\users\user"
call :make_dir "%PROJECT%\storage\users\user\default"

echo  OK — All folders created.

:: ────────────────────────────────────────────────────────────
:: STEP 2 — Create default JSON files (only if missing)
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 2] Creating default settings files...
echo  ---------------------------------------------

:: history.json — empty array
if not exist "%PROJECT%\history.json" (
    echo [] > "%PROJECT%\history.json"
    echo  Created: history.json
) else (
    echo  Exists:  history.json  (skipped)
)

:: folders.json — default folder list
if not exist "%PROJECT%\folders.json" (
    (
    echo ["default","vehicles","creatures","buildings","misc"]
    ) > "%PROJECT%\folders.json"
    echo  Created: folders.json
) else (
    echo  Exists:  folders.json  (skipped)
)

:: state.json — idle state
if not exist "%PROJECT%\state.json" (
    (
    echo {
    echo   "status":   "idle",
    echo   "prompt":   "",
    echo   "step":     "ready",
    echo   "progress": 0,
    echo   "service":  "",
    echo   "error":    "",
    echo   "log":      []
    echo }
    ) > "%PROJECT%\state.json"
    echo  Created: state.json
) else (
    echo  Exists:  state.json  (skipped)
)

:: storage/users/user/index.json — empty array
if not exist "%PROJECT%\storage\users\user\index.json" (
    echo [] > "%PROJECT%\storage\users\user\index.json"
    echo  Created: storage\users\user\index.json
) else (
    echo  Exists:  storage\users\user\index.json  (skipped)
)

echo  OK — Settings files ready.

:: ────────────────────────────────────────────────────────────
:: STEP 3 — Install required Python packages
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 3] Installing Python packages...
echo  ----------------------------------------
echo  (This may take a few minutes on first run)
echo.

python --version > nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  ERROR: Python not found!
    echo  Download it from: https://www.python.org/downloads/
    echo  Check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

pip install flask flask-cors requests pystray pillow groq

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  WARNING: Some packages may have failed to install.
    echo  Check the output above for red error lines.
    echo  You can retry by running:
    echo      pip install flask flask-cors requests pystray pillow groq
    echo.
) else (
    echo.
    echo  OK — All packages installed!
)

:: ────────────────────────────────────────────────────────────
:: STEP 4 — Check for Blender (optional, used for advanced export)
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 4] Checking for Blender...
echo  ----------------------------------

:: Common Blender install paths on Windows
set "BLENDER_FOUND=NO"

if exist "C:\Program Files\Blender Foundation\Blender 4.0\blender.exe" (
    set "BLENDER_PATH=C:\Program Files\Blender Foundation\Blender 4.0\blender.exe"
    set "BLENDER_FOUND=YES"
)
if exist "C:\Program Files\Blender Foundation\Blender 3.6\blender.exe" (
    set "BLENDER_PATH=C:\Program Files\Blender Foundation\Blender 3.6\blender.exe"
    set "BLENDER_FOUND=YES"
)
if exist "C:\Program Files\Blender Foundation\Blender 3.5\blender.exe" (
    set "BLENDER_PATH=C:\Program Files\Blender Foundation\Blender 3.5\blender.exe"
    set "BLENDER_FOUND=YES"
)

:: Also check if blender is in system PATH
where blender > nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set "BLENDER_FOUND=YES"
    for /f "tokens=*" %%b in ('where blender 2^>nul') do set "BLENDER_PATH=%%b"
)

if "%BLENDER_FOUND%"=="YES" (
    echo  OK — Blender found at: %BLENDER_PATH%
) else (
    echo  NOTE: Blender was not found on this computer.
    echo  Blender is optional — you can still use AI generation.
    echo  To install Blender, visit: https://www.blender.org/download/
)

:: ────────────────────────────────────────────────────────────
:: STEP 5 — Run folder_init.py for final structure check
:: ────────────────────────────────────────────────────────────
echo.
echo  [Step 5] Running folder initializer...
echo  ----------------------------------------

if exist "%PROJECT%\folder_init.py" (
    python "%PROJECT%\folder_init.py"
    echo  OK — Folder check complete.
) else (
    echo  NOTE: folder_init.py not found, skipping.
    echo  Folders were already created in Step 1.
)

:: ────────────────────────────────────────────────────────────
:: SUMMARY
:: ────────────────────────────────────────────────────────────
echo.
echo  =====================================================
echo   Setup complete!
echo  =====================================================
echo.
echo  What was created:
echo    Folders : models\, models\cache\, models\presets\
echo              logs\, storage\, storage\users\user\
echo              storage\users\user\default\
echo    Files   : history.json, folders.json, state.json
echo              storage\users\user\index.json
echo    Packages: flask, flask-cors, requests,
echo              pystray, pillow, groq
echo.
echo  NEXT STEPS:
echo    1. Run tray_launcher.pyw to start the app
echo       (double-click it in File Explorer)
echo.
echo    2. To enable AI 3D generation, run:
echo       install_shapee.bat
echo.
echo  Press any key to close this window...
pause > nul
goto :eof

:: ────────────────────────────────────────────────────────────
:: HELPER: create directory (silent, no error if exists)
:: ────────────────────────────────────────────────────────────
:make_dir
if not exist "%~1\" (
    mkdir "%~1" 2>nul
    echo  Created: %~1
) else (
    echo  Exists:  %~1  (skipped)
)
goto :eof
